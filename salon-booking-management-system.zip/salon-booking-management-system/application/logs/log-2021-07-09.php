<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-09 07:11:44 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;smtp.example.com&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\salon-booking-management-system\system\libraries\Email.php 1888
