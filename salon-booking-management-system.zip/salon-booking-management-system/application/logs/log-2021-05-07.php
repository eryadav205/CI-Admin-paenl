<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-07 19:41:51 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:41:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:41:51 --> Unable to connect to the database
ERROR - 2021-05-07 19:48:54 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:48:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:48:55 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:32 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:32 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Unable to connect to the database
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:49:39 --> Unable to connect to the database
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Unable to connect to the database
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Unable to connect to the database
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Unable to connect to the database
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\salon-booking-management-system\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-07 19:50:44 --> Unable to connect to the database
ERROR - 2021-05-07 19:52:44 --> Severity: Warning --> file_get_contents(C:\xampp\htdocs\salon-booking-management-system\application\views/install/includes/version.php): failed to open stream: No such file or directory C:\xampp\htdocs\salon-booking-management-system\application\models\InstallModel.php 56
ERROR - 2021-05-07 19:56:44 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;smtp.gmail.com&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\salon-booking-management-system\system\libraries\Email.php 1888
